stock HMI provissioner for edatech ED-HMI2220-070

install-hpc-hmi
bin/
├── HPC_LinuxGUI
├── assets/
└── settings.txt

# build / rebuild:  

installer-venv/bin/pyinstaller \
    --onefile \
    --name install-hpc-stock \
    stock-hmi.py
    
# Method:
use this script to setup a stock OS to run the HPC software, and provission the OS.

Update the installer with whatever stub from the HPC_LinuxGUI
as a pre-compiled arm binary. 

# Chang password:

APP_PASSWORD_HASH = 

openssl passwd -6 <new_password>  
