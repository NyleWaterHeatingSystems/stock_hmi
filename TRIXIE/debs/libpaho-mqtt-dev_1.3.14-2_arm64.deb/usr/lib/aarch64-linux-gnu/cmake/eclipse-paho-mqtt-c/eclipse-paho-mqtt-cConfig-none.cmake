#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "eclipse-paho-mqtt-c::paho-mqtt3c" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3c APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3c PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3c.so.1.3.14"
  IMPORTED_SONAME_NONE "libpaho-mqtt3c.so.1"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3c )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3c "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3c.so.1.3.14" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3a" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3a APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3a PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3a.so.1.3.14"
  IMPORTED_SONAME_NONE "libpaho-mqtt3a.so.1"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3a )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3a "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3a.so.1.3.14" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3c-static" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3c-static APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3c-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3c.a"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3c-static )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3c-static "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3c.a" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3a-static" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3a-static APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3a-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3a.a"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3a-static )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3a-static "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3a.a" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3cs" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3cs APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3cs PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3cs.so.1.3.14"
  IMPORTED_SONAME_NONE "libpaho-mqtt3cs.so.1"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3cs )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3cs "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3cs.so.1.3.14" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3as" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3as APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3as PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3as.so.1.3.14"
  IMPORTED_SONAME_NONE "libpaho-mqtt3as.so.1"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3as )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3as "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3as.so.1.3.14" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3cs-static" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3cs-static APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3cs-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3cs.a"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3cs-static )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3cs-static "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3cs.a" )

# Import target "eclipse-paho-mqtt-c::paho-mqtt3as-static" for configuration "None"
set_property(TARGET eclipse-paho-mqtt-c::paho-mqtt3as-static APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(eclipse-paho-mqtt-c::paho-mqtt3as-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3as.a"
  )

list(APPEND _cmake_import_check_targets eclipse-paho-mqtt-c::paho-mqtt3as-static )
list(APPEND _cmake_import_check_files_for_eclipse-paho-mqtt-c::paho-mqtt3as-static "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpaho-mqtt3as.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
